<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ProductsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $now = now();
            DB::table('products')->insert([
                'brand_id' => 1,
                'image' => "https://i.pinimg.com/736x/51/82/ff/5182ff38659e90ae877c02f63d7a28c9.jpg",
                'price' => 120000,
                'name' => "Zara Flower Cardigan",
                'qty' => 10,
                'created_at' => $now,
                'updated_at' => $now,
            ]);
            DB::table('products')->insert([
                'brand_id' => 1,
                'image' => "https://i.pinimg.com/736x/46/56/d0/4656d0670b0f534ce81141d4179a7620.jpg",
                'price' => 150000,
                'name' => "Zara Casual Blazer",
                'qty' => 8,
                'created_at' => $now,
                'updated_at' => $now,
            ]);
            DB::table('products')->insert([
                'brand_id' => 2, // Colorbox
                'image' => "https://i.pinimg.com/736x/74/6a/23/746a2313b5cd2d7665db2cbc6acef44f.jpg",
                'price' => 85000,
                'name' => "Colorbox Graphic T-Shirt",
                'qty' => 15,
                'created_at' => $now,
                'updated_at' => $now,
            ]);
            DB::table('products')->insert([
                'brand_id' => 2,
                'image' => "https://i.pinimg.com/736x/ed/1c/df/ed1cdf2cd4beed71b946935f396648d9.jpg",
                'price' => 70000,
                'name' => "Colorbox Denim Shorts",
                'qty' => 12,
                'created_at' => $now,
                'updated_at' => $now,
            ]);
            DB::table('products')->insert([
                'brand_id' => 3, // H&M
                'image' => "https://i.pinimg.com/736x/6c/1e/43/6c1e4320d858fb66e95c57342a4b2566.jpg",
                'price' => 95000,
                'name' => "H&M Cotton Shirt",
                'qty' => 20,
                'created_at' => $now,
                'updated_at' => $now,
            ]);
            DB::table('products')->insert([
                'brand_id' => 3,
                'image' => "https://i.pinimg.com/736x/21/74/ef/2174ef788b8ebc2a0f647da9e60bb10f.jpg",
                'price' => 130000,
                'name' => "H&M Winter Sweater",
                'qty' => 5,
                'created_at' => $now,
                'updated_at' => $now,
            ]);
            DB::table('products')->insert([
                'brand_id' => 4, // Uniqlo
                'image' => "https://i.pinimg.com/736x/a2/14/5d/a2145d75bb8e7e5e5fd9a5b4e3b54e50.jpg",
                'price' => 125000,
                'name' => "Uniqlo Fleece Jacket",
                'qty' => 10,
                'created_at' => $now,
                'updated_at' => $now,
            ]);
            DB::table('products')->insert([
                'brand_id' => 4,
                'image' => "https://i.pinimg.com/736x/bd/23/36/bd233617c20d7f1eb19a86df85f4b7dc.jpg",
                'price' => 90000,
                'name' => "Uniqlo Basic T-Shirt",
                'qty' => 25,
                'created_at' => $now,
                'updated_at' => $now,
            ]);
            DB::table('products')->insert([
                'brand_id' => 5, // Stradivarius
                'image' => "https://i.pinimg.com/736x/72/0f/6f/720f6f8e3b6f8c8c9d5788b0933f0c26.jpg",
                'price' => 140000,
                'name' => "Stradivarius Plaid Skirt",
                'qty' => 7,
                'created_at' => $now,
                'updated_at' => $now,
            ]);
            DB::table('products')->insert([
                'brand_id' => 5,
                'image' => "https://i.pinimg.com/736x/8e/f3/5b/8ef35b1c618b0c9829f5cf4469200a63.jpg",
                'price' => 160000,
                'name' => "Stradivarius Faux Leather Jacket",
                'qty' => 6,
                'created_at' => $now,
                'updated_at' => $now,
            ]);

    }
}
