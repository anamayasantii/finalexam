<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $keyword = $request->get('keyword');  // Default to empty string if no keyword is provided
        $brandName = $request->get('brand_name');

        $query = Product::query();

        if ($keyword) {
            $query = $query->where('name', 'like', "%{$keyword}%");
        }

        if ($brandName) {
            $query->join('brands', 'products.brand_id', '=', 'brands.id')
            ->select('products.*', 'brands.name as brand_name')
            ->where('brands.name', 'like', "%{$brandName}%");
        }

        $products = $query->orderBy('id')->paginate(10);

        return response()->json($products);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'brand_id' => 'required|integer|exists:brands,id',
            'image' => 'required|string',
            'name' => 'required|string',
            'price' => 'required|numeric',
            'qty' => 'required|integer',
        ], [
            'brand_id.required' => 'Brand ID wajib diisi',
            'brand_id.integer' => 'Brand ID harus berupa angka',
            'brand_id.exists' => 'Brand ID harus sesuai dengan yang ada di tabel brands',
            'image.required' => 'Gambar produk wajib diisi',
            'image.string' => 'Gambar produk berupa link',
            'name.required' => 'Nama produk wajib diisi',
            'name.string' => 'Nama produk harus berupa teks',
            'price.required' => 'Harga produk wajib diisi',
            'price.numeric' => 'Harga harus berupa angka',
            'qty.required' => 'Quantity produk wajib diisi',
            'qty.integer' => 'Quantity harus berupa bilangan bulat',
        ]);

        Product::create($validatedData);
        return response()->json(['message' => 'Produk berhasil disimpan'], 201);
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $product = Product::findOrFail($id);

        return response()->json($product);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $product = Product::findOrFail($id);
        $product->update($request->all());
        return response()->json(['message' => 'Produk berhasil diupdate'], 200);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $product = Product::findOrFail($id);
        $product->delete();

        return response()->json(['message' => 'Produk berhasil dihapus'], 200);
    }
}
